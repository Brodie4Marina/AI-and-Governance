# Next Steps

## Immediate Goal

The next step is to turn the research idea into a minimal GitHub repository that demonstrates empirical AI safety thinking.

The repository does not need to be large. It needs to show that the problem is concrete, measurable, and capable of being tested.

## Step 1: Create the Repository

Suggested repository name:

```text
ai-legal-ambiguity-benchmark
```

Suggested GitHub description:

```text
Benchmark for evaluating whether language models ask jurisdictional clarifying questions before answering legally sensitive prompts.
```

## Step 2: Upload the Core Files

Upload the following first:

```text
README.md
requirements.txt
data/prompts.csv
src/scoring.py
src/run_eval.py
results/sample_results.csv
```

Do not overbuild the repository at the beginning. A clean, modest research prototype is better than an unfinished ambitious system.

## Step 3: Add the Prompt Dataset

Start with 30 to 50 prompts.

Use domains where jurisdiction clearly matters:

- employment termination;
- severance;
- eviction;
- workplace recording;
- privacy rights;
- trustee duties;
- shareholder disputes;
- foreign income tax;
- immigration status;
- contract remedies.

Each prompt should include:

- prompt text;
- language;
- domain;
- whether jurisdiction is required;
- expected safe behavior;
- risk level.

## Step 4: Add a Simple Scoring Script

The first scoring script can be rule-based.

It should check whether the model response contains phrases such as:

- “which jurisdiction”;
- “which country”;
- “which state”;
- “depends on where”;
- “jurisdiction matters”;
- “I need to know where.”

This is not perfect, but it is enough for a first empirical prototype.

## Step 5: Add Sample Results

Create sample model responses manually at first, then run the scoring script.

The point is to show the structure of the evaluation.

## Step 6: Write a Short Research Note

Add a short file later called:

```text
research_note.md
```

It should explain:

- the safety failure;
- the benchmark design;
- preliminary findings;
- limitations;
- future work.

## Step 7: Prepare the Anthropic Application Language

The application should say:

```text
I am developing a small empirical benchmark to test whether language models recognize jurisdictional ambiguity in legal and administrative prompts. The project evaluates whether models ask clarifying questions before answering, whether they silently default to a jurisdiction, and whether multilingual prompts increase misselection risk.
```

## Minimum Viable Version

The minimum viable version is complete when the repository has:

1. a clear README;
2. a small prompt dataset;
3. a scoring rubric;
4. a simple scoring script;
5. sample results;
6. a short explanation of why the benchmark matters for AI safety.

## Practical Standard

This project should not pretend to be a finished legal AI system.

It should present itself as a serious evaluation prototype.

That is enough.
