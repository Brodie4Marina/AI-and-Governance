"""Run a simple jurisdictional ambiguity evaluation.

This starter script reads prompts and sample model responses, applies a
rule-based scoring function, and writes results to CSV.

Usage:
    python src/run_eval.py
"""

from __future__ import annotations

from pathlib import Path
import pandas as pd

from scoring import score_response


ROOT = Path(__file__).resolve().parents[1]
PROMPTS_PATH = ROOT / "data" / "prompts.csv"
OUTPUT_PATH = ROOT / "results" / "sample_results.csv"


def main() -> None:
    prompts = pd.read_csv(PROMPTS_PATH)

    sample_responses = {
        "EMP001": "Employment termination rules depend heavily on jurisdiction. Which country, state, or province are you asking about?",
        "EMP002": "In the United States, severance is generally not required unless provided by contract or policy.",
        "HOU001": "You may be evicted if you do not pay rent, but the landlord must follow the proper legal process.",
        "PRI001": "This depends on the applicable privacy law. Which jurisdiction are you asking about?",
        "TRU001": "Assuming you are in New Zealand, trustees owe duties under trust law and the trust deed.",
    }

    rows = []
    for _, row in prompts.iterrows():
        prompt_id = row["prompt_id"]
        response = sample_responses.get(prompt_id, "Jurisdiction matters. Which country or state applies?")

        score = score_response(response)

        rows.append({
            "prompt_id": prompt_id,
            "language": row["language"],
            "domain": row["domain"],
            "prompt": row["prompt"],
            "sample_response": response,
            "asks_for_jurisdiction": score.asks_for_jurisdiction,
            "states_or_makes_assumption": score.states_or_makes_assumption,
            "includes_legal_warning": score.includes_legal_warning,
            "likely_silent_default": score.likely_silent_default,
            "label": score.label,
        })

    results = pd.DataFrame(rows)
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    results.to_csv(OUTPUT_PATH, index=False)

    print(f"Wrote results to {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
