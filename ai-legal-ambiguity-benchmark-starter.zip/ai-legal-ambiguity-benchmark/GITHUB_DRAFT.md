# GitHub Draft

## Repository Name

```text
ai-legal-ambiguity-benchmark
```

## Short Description

```text
Benchmark for evaluating whether language models ask jurisdictional clarifying questions before answering legally sensitive prompts.
```

## Longer GitHub About Section

```text
AI Legal Ambiguity Benchmark is a research prototype for evaluating a specific legal-domain AI safety failure: whether language models answer jurisdiction-dependent legal questions without first asking which jurisdiction applies.

The project tests multilingual legal and administrative prompts across domains such as employment, housing, privacy, trusts, tax, and corporate governance. It measures clarification rate, silent default rate, assumption transparency, and wrong-default risk.

The core safety principle is: clarify first, answer second.
```

## Suggested Repository Topics

```text
ai-safety
ai-governance
legal-ai
llm-evaluation
benchmark
jurisdiction
legal-tech
multilingual-ai
responsible-ai
```

## First GitHub Commit Message

```text
Initial benchmark structure for jurisdictional ambiguity evaluation
```

## Suggested README Tagline

```text
Testing whether language models clarify jurisdiction before giving legal information.
```

## Suggested Pinned Repository Summary

```text
This project evaluates whether language models recognize jurisdictional ambiguity in legal prompts. It focuses on the safety behavior of asking clarifying questions before answering jurisdiction-dependent legal questions.
```

## Suggested Issue 1

Title:

```text
Build initial multilingual prompt dataset
```

Body:

```text
Create an initial dataset of 30 to 50 jurisdictionally ambiguous legal and administrative prompts across employment, housing, privacy, tax, trusts, and corporate governance. Include English first, then add Japanese, Chinese, French, and German examples.
```

## Suggested Issue 2

Title:

```text
Implement baseline clarification scoring
```

Body:

```text
Create a simple rule-based scoring function that detects whether a model response asks for jurisdiction, states that jurisdiction is missing, transparently assumes a jurisdiction, or silently defaults to a legal system.
```

## Suggested Issue 3

Title:

```text
Add sample evaluation results
```

Body:

```text
Run the baseline scoring script on a small sample of model responses and save the output to results/sample_results.csv. Use this to demonstrate the evaluation structure before expanding the benchmark.
```

## Suggested Issue 4

Title:

```text
Draft short research note
```

Body:

```text
Write a short research note explaining jurisdictional ambiguity as a legal-domain AI safety failure, the benchmark design, preliminary limitations, and future work.
```

## Suggested Pull Request Title

```text
Add initial legal ambiguity benchmark prototype
```

## Suggested Pull Request Description

```text
This pull request adds the initial structure for the AI Legal Ambiguity Benchmark. It includes a README, starter prompt dataset, baseline scoring logic, sample evaluation output, and project next steps.

The benchmark evaluates whether language models ask jurisdictional clarifying questions before answering legally sensitive prompts.
```
